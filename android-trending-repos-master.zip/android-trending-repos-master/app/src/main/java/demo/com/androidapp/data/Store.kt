package demo.com.androidapp.data

import demo.com.androidapp.data.models.Item

/**
 * Created by sundayakinsete on 28/01/2018.
 */
object Store{

    var viewedRepo: Item? = null
}