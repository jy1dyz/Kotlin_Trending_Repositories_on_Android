# android-trending-repos
A list of trending Github repositories of android built with kotlin
